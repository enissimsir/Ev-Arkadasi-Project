package com.example.evarkadasi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Objects;

// randevu al, randevularım, info, profil: ayarlar, cüzdan, çıkış, geçmiş randevular

public class StudentMainPage extends AppCompatActivity {
    private CardView searchCW;
    private CardView myRoomsCW;
    private CardView profileCW;
    private CardView infoCW;
    private FirebaseFirestore db;
    private FirebaseUser mUser;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_main_page);

        searchCW = findViewById(R.id.getAppointmentCW);
        myRoomsCW = findViewById(R.id.myAppointmentsCW);
        profileCW = findViewById(R.id.profileCW);
        infoCW = findViewById(R.id.infoCW);

        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        db = FirebaseFirestore.getInstance();

        searchCW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("Users").document(mUser.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()){
                            if(Objects.requireNonNull(documentSnapshot.getString("userStat")).equals("searching")){
                                if(documentSnapshot.contains("searchingHomeLength") && documentSnapshot.contains("searchingHomeTime")){
                                    Intent intent = new Intent(getApplicationContext(), Search.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(StudentMainPage.this,"Arama ekranına erişmek için profilinizden istediğiniz kriterleri doldurun",Toast.LENGTH_LONG).show();
                                }
                            }
                            else {
                                Toast.makeText(StudentMainPage.this,"Arama ekranına erişmek için profil durumunuzu arıyor olarak güncelleyin",Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                });
            }
        });
        myRoomsCW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final boolean[] doesHaveRoom = new boolean[1];
                db.collection("Users").document(mUser.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()){
                            if(!Boolean.TRUE.equals(documentSnapshot.getBoolean("doesHaveRoom"))){
                                Toast.makeText(StudentMainPage.this,"odan yok",Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(getApplicationContext(), NotHaveRoom.class);
                                startActivity(intent);
                            }
                            else Toast.makeText(StudentMainPage.this,"odan var",Toast.LENGTH_LONG).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(StudentMainPage.this,e.getMessage().toString(),Toast.LENGTH_LONG).show();
                    }
                });
       /*         Intent intent = new Intent(getApplicationContext(), MyAppointments.class);
                startActivity(intent); */
            }
        });
        profileCW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Profile.class);
                startActivity(intent);
            }
        });
    }
}