package com.example.evarkadasi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class Search extends AppCompatActivity {
    private FirebaseUser mUser;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private DocumentReference userRef;

    ArrayList<HomeList> homeList = new ArrayList<>();

    private void setUpHomeLists() {
        db.collection("Homes").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    List<DocumentSnapshot> documents = task.getResult().getDocuments();
                    System.out.println("document sayisi: " + documents.size());
                    int documentCount = documents.size();
                    AtomicInteger processedDocuments = new AtomicInteger(0);

                    for (DocumentSnapshot document : documents) {
                        prefControl(document, new OnPrefControlCompleteListener() {
                            @Override
                            public void onPrefControlComplete(boolean result, DocumentSnapshot document) {
                                if (result) {
                                    System.out.println("sayildi");
                                    HomeList newHome = new HomeList(document.getId(), document.getString("homeBio"), document.getString("ownerName"),
                                            document.getString("homeLength"), document.getString("homeTime"));
                                    System.out.println("yeni ev: " + newHome.toString());
                                    homeList.add(newHome);
                                } else {
                                    System.out.println("sayilmadi");
                                }
                                int count = processedDocuments.incrementAndGet();
                                if (count == documentCount) {
                                    // Tüm dokümanlar işlendi, afterSetUpHomeLists() metodu çalıştırılabilir
                                    afterSetUpHomeLists();
                                }
                            }
                        });
                    }
                } else {
                    Toast.makeText(Search.this, "vt hatasi", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void prefControl(DocumentSnapshot ev, OnPrefControlCompleteListener listener) {
        System.out.println("ev: " + ev.toString());
        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        if (ev.getString("homeLength") != null && ev.getString("homeTime") != null) {
            System.out.println("Bu eve bakalim");
            int homeLength = Integer.parseInt(Objects.requireNonNull(ev.getString("homeLength")));
            int homeTime = Integer.parseInt(Objects.requireNonNull(ev.getString("homeTime")));
            DocumentReference userRef = db.collection("Users").document(mAuth.getUid());
            System.out.println("deneyelim1");
            userRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            int searchingLength = Integer.parseInt(Objects.requireNonNull(document.getString("searchingHomeLength")));
                            int searchingTime = Integer.parseInt(Objects.requireNonNull(document.getString("searchingHomeTime")));
                            System.out.println(searchingLength + " " + searchingTime);
                            if (searchingLength >= homeLength && searchingTime <= homeTime) {
                                listener.onPrefControlComplete(true, ev);
                            } else {
                                listener.onPrefControlComplete(false, ev);
                            }
                        } else {
                            listener.onPrefControlComplete(false, ev);
                        }
                    } else {
                        listener.onPrefControlComplete(false, ev);
                    }
                }
            });
        } else {
            listener.onPrefControlComplete(false, ev);
        }
    }

    private interface OnPrefControlCompleteListener {
        void onPrefControlComplete(boolean result, DocumentSnapshot document);
    }

    private void processPrefControlResult(boolean result, DocumentSnapshot document) {
        if (result) {
            System.out.println("sayildi");
            HomeList newHome = new HomeList(document.getId(), document.getString("homeBio"), document.getString("ownerName"),
                    document.getString("homeLength"), document.getString("homeTime"));
            System.out.println("yeni ev: " + newHome.toString());
            homeList.add(newHome);
        }else{
            System.out.println("sayilmadi");
        }
    }

    private void afterSetUpHomeLists() {
        System.out.println("ev sayisi: " + homeList.size());
        for(HomeList home : homeList){
            System.out.println("evsahibi: " + home.getOwnerName() + "ev biosu: " + home.getBio());
        }

        RecyclerView recyclerView = findViewById(R.id.mRecyclerView);
        HL_RecyclerViewAdapter adapter = new HL_RecyclerViewAdapter(Search.this,homeList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Search.this));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        db = FirebaseFirestore.getInstance();
        userRef = db.collection("Users").document(mUser.getUid());

        setUpHomeLists();
    }
}