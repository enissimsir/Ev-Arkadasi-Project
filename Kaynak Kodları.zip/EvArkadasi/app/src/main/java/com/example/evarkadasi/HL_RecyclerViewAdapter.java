package com.example.evarkadasi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HL_RecyclerViewAdapter extends RecyclerView.Adapter<HL_RecyclerViewAdapter.MyViewHolder> {
    Context context;
    ArrayList<HomeList> homeList;

    public HL_RecyclerViewAdapter(Context context, ArrayList<HomeList> homeList){
        this.context = context;
        this.homeList = homeList;
    }

    @NonNull
    @Override
    public HL_RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.search_row, parent, false);
        return new HL_RecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HL_RecyclerViewAdapter.MyViewHolder holder, int position) {
        holder.userName.setText(homeList.get(position).getOwnerName());
        holder.homeBio.setText(homeList.get(position).getBio());
        holder.homeLength.setText(homeList.get(position).getLength());
        holder.homeTime.setText(homeList.get(position).getTime());
    }

    @Override
    public int getItemCount() {
        return homeList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView userName, homeBio, homeLength, homeTime;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.textView_evSahibi);
            homeBio = itemView.findViewById(R.id.textView_bio);
            homeLength = itemView.findViewById(R.id.textView_kampuseUzaklik);
            homeTime = itemView.findViewById(R.id.textView_paylasimSuresi);
        }
    }
}
