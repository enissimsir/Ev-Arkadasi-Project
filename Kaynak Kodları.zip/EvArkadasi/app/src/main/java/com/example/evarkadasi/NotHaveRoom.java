package com.example.evarkadasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NotHaveRoom extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_not_have_room);
    }
}