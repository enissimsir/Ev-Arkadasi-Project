package com.example.evarkadasi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Profile extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    private FirebaseUser mUser;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private DocumentReference userRef;
    private String stat;
    private String curStat;
    private EditText editText_name;
    private EditText editText_telno;
    private EditText editText_education;
    private EditText editText_homeLength;
    private EditText editText_homeTime;
    private Button button_save;
    private Button buttonRoomMan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        db = FirebaseFirestore.getInstance();
        userRef = db.collection("Users").document(mUser.getUid());
        stat = null;

        editText_name = findViewById(R.id.editTextName);
        editText_telno = findViewById(R.id.editTextTelNo);
        editText_education = findViewById(R.id.editTextEducation);
        editText_homeLength = findViewById(R.id.editTextEvUzakligi);
        editText_homeTime = findViewById(R.id.editTextEvPaylasimSuresi);
        button_save = findViewById(R.id.buttonSave);
        buttonRoomMan = findViewById(R.id.buttonRoomMan);

        userRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                curStat = documentSnapshot.getString("userStat");

                if (curStat != null && !curStat.equals("searching")) {
                    editText_homeLength.setVisibility(View.INVISIBLE);
                    editText_homeTime.setVisibility(View.INVISIBLE);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                System.out.println("hataaa");
                curStat = "nothing";
            }
        });

        button_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map<String, Object> updatedData = new HashMap<>();
                String userName = editText_name.getText().toString();
                String telNo= editText_telno.getText().toString();
                String education = editText_education.getText().toString();
                String homeLength = editText_homeLength.getText().toString();
                String homeTime = editText_homeTime.getText().toString();
                if (!userName.equals("")){
                    updatedData.put("userName", userName);
                }
                if(!telNo.equals("")){
                    updatedData.put("userTelNo", telNo);
                }
                if(!education.equals("")){
                    updatedData.put("userEducation", education);
                }
                if(!homeLength.equals("")){
                    updatedData.put("searchingHomeLength", homeLength);
                }
                if(!homeTime.equals("")){
                    updatedData.put("searchingHomeTime", homeTime);
                }
                if(stat!=null){
                    updatedData.put("userStat", stat);
                }
                userRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()){
                            Map<String, Object> userData = documentSnapshot.getData();
                            assert userData != null;
                            userData.putAll(updatedData);

                            userRef.set(userData).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(Profile.this,"Güncelleme başarılı",Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), Profile.class);
                                    startActivity(intent);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(Profile.this, "Güncelleme başarısız", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });
            }
        });
        buttonRoomMan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RoomManagement.class);
                startActivity(intent);
            }
        });
    }



    private void veriGuncelle(String key, String val, OnSuccessListener<Void> listener){
        userRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()){
                    Map<String, Object> userData = documentSnapshot.getData();
                    Map<String, Object> updatedData = new HashMap<>();
                    updatedData.put(key, val);
                    // Mevcut verileri güncelleyin
                    assert userData != null;
                    userData.putAll(updatedData);

                    // Firestore'a yükleyin
                    userRef.set(userData).addOnSuccessListener(listener).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Profile.this, "Güncelleme başarısız", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(Profile.this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    public boolean onMenuItemClick(MenuItem item) {
        System.out.println("uc");
        switch (item.getItemId()) {
            case R.id.item1:
                stat="searching";
                return true;
            case R.id.item2:
                stat="renting";
                return true;
            case R.id.item3:
                stat="nothing";
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}