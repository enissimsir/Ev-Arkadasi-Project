package com.example.evarkadasi;

public class HomeList {
    String id;
    String bio;
    String ownerName;
    String length;
    String time;

    @Override
    public String toString() {
        return "HomeList{" +
                "id='" + id + '\'' +
                ", bio='" + bio + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", length='" + length + '\'' +
                ", time='" + time + '\'' +
                '}';
    }

    public HomeList(String id, String bio, String ownerName, String length, String time) {
        this.id = id;
        this.bio = bio;
        this.ownerName = ownerName;
        this.length = length;
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public String getBio() {
        return bio;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getLength() {
        return length;
    }

    public String getTime() {
        return time;
    }
}
