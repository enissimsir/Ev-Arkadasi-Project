package com.example.evarkadasi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RoomManagement extends AppCompatActivity {
    private EditText homeBio;
    private EditText homeLength;
    private EditText homeTime;
    private Button button;
    private FirebaseUser mUser;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private DocumentReference userRef;
    private CollectionReference collectionRef;
    private String bio;
    private String length;
    private String time;
    private String homeID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_management);

        homeBio = findViewById(R.id.homeBio);
        homeLength = findViewById(R.id.homeLength);
        homeTime = findViewById(R.id.homeTime);
        button = findViewById(R.id.button);

        mAuth = FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        db = FirebaseFirestore.getInstance();
        userRef = db.collection("Users").document(mUser.getUid());
        collectionRef = db.collection("Homes");



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bio = homeBio.getText().toString();
                length = homeLength.getText().toString();
                time = homeTime.getText().toString();

                userRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        homeID = documentSnapshot.getString("homeID");
                        assert homeID != null;
                        if (homeID.equals("none")) {
                            Map<String, Object> dataHome = new HashMap<>();
                            dataHome.put("ownerID", mUser.getUid());
                            dataHome.put("ownerName", documentSnapshot.getString("userName"));

                            collectionRef.add(dataHome).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    homeID = documentReference.getId();
                                    System.out.println("Yeni belge oluşturuldu. ID: " + homeID);
                                    Map<String, Object> updatedUserData = new HashMap<>();
                                    updatedUserData.put("homeID", homeID);

                                    Map<String, Object> userData = documentSnapshot.getData();
                                    assert userData != null;
                                    userData.putAll(updatedUserData);

                                    userRef.set(userData).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            Toast.makeText(RoomManagement.this,"Başarılı",Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                    // Yeni belge oluşturulduktan sonra güncelleme işlemlerini gerçekleştir
                                    updateHomeData();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(RoomManagement.this, "Güncelleme başarısız", Toast.LENGTH_SHORT).show();
                                }
                            });
                        } else {
                            // homeID zaten varsa direkt güncelleme işlemlerini gerçekleştir
                            updateHomeData();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(RoomManagement.this,"Veritabanına ulaşılamadı",Toast.LENGTH_SHORT).show();
                    }
                });
            }
            private void updateHomeData() {
                DocumentReference homeRef = collectionRef.document(homeID);
                Map<String, Object> dataHome = new HashMap<>();
                if (!bio.equals("")) {
                    dataHome.put("homeBio", bio);
                }
                if (!length.equals("")) {
                    dataHome.put("homeLength", length);
                }
                if (!time.equals("")) {
                    dataHome.put("homeTime", time);
                }

                homeRef.update(dataHome).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        System.out.println("Ev verisi güncelleme işlemi tamam");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        System.out.println("Ev verisi güncelleme işleminde hata");
                    }
                });
            }
        });

    }
}